//api credentials
async function fetchData(query) {
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '',
        'X-RapidAPI-Host': 'wiki-briefs.p.rapidapi.com'
      }
    };
  
    //call api
    const res = await fetch(`https://wiki-briefs.p.rapidapi.com/search?q=${query}&topk=3`, options);
    const response = await res.json();
    console.log(response)
  
    //summary is the response of the API per searchInput
    const summary = response['summary'];
  
    //URL for summary response
    const mainUrl = response['url'];
  
    //similar is similar response(s) of the API per searchInput 
    const similar = response['similar']
  
    //HTML variable for output 
    const outputElement = document.getElementById("output");
  
    if (summary && summary.length > 0) {
      //summary
      const listSummary = summary.map(item => `<li>${item}</li>`).join('');
      const summaryList = `<ul>${listSummary}</ul><br>`;
  
      //string for "Other results for "searchInput"
      const otherResults = `<p class = other-results><b>Other results for "${query}"</b></p><br>`;
  
      //URL(s) of other similar search results
      const listSimilar = similar.map(item => `<li><a href="${item.url}" target="_blank">${item.title}</a></li>`).join('');
      const similarList = `<ul>${listSimilar}</ul>`;
  
  
      outputElement.innerHTML = `${summaryList}<p class='more-info'><b>More information about "${query}": <a href="${mainUrl}" target="_blank">HERE</a></b><br></p>${otherResults}${similarList}`;
    } else {
      outputElement.innerHTML = `<p class='no-data'><b>No data available on "${query}"</b></p>`;
    }
  }
  
  const searchButton = document.getElementById("searchButton");
  searchButton.addEventListener("click", function() {
    const searchInput = document.getElementById("searchInput").value;
    fetchData(searchInput);
  });